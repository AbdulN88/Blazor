﻿using Blazor.Server.DbContexts;
using Blazor.Server.Repos;
using Blazor.Server.Repos.Intefaces;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Blazor.Server.Infrastructure
{
    public class RepositoryModule : NinjectModule
    {
        public override void Load()
        {
            Bind<BlazorDatabaseContext>().ToSelf().InTransientScope();
            Bind<ICustomerRepo>().To<CustomerRepo>();
        }
    }
}
