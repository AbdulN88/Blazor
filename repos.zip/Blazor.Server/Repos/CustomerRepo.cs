﻿using Blazor.Server.DbContexts;
using Blazor.Server.Repos.Intefaces;
using Blazor.Shared.Models;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Blazor.Server.Repos
{
    public class CustomerRepo : ICustomerRepo
    {
        public IEnumerable<Customer> GetCustomers()
        {
            var customers = new List<Customer>();

            using (var context = BlazorDatabaseContext.DbContext)
            {
                customers = context.Connection.Query<Customer>("[dbo].[GetCustomers]", CommandType.StoredProcedure).ToList();
            }

            return customers;
        }

        public void CreateCustomers(Customer customer)
        {
            var parameters = new DynamicParameters();

            parameters.Add("@FirstName", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@LastName", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@AddressLine1", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@AddressLine2", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@AddressLine3", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@City", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@County", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@PostCode", customer.FirstName, DbType.String, ParameterDirection.Input);
            parameters.Add("@DateOfBirth", customer.FirstName, DbType.DateTime, ParameterDirection.Input);
    
            using (var context = BlazorDatabaseContext.DbContext)
            {
                context.Connection.Execute("[dbo].[CreateCustomers]", parameters, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
