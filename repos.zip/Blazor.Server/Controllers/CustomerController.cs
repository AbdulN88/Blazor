﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Blazor.Server.Repos.Intefaces;
using Blazor.Shared.Models;
using Microsoft.AspNetCore.Mvc;

namespace Blazor.Server.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerRepo _customerRepo;

        public CustomerController(ICustomerRepo customerRepo)
        {
            this._customerRepo = customerRepo;
        }

        //public IActionResult Index()
        //{
        //    return View();
        //}

        [HttpGet]
        [Route("api/Customer/GetAllCustomers")]
        public IEnumerable<Customer> GetAllCustomers()
        {
            var customers = new List<Customer>();

            try
            {
                var result = this._customerRepo.GetCustomers();
                customers.AddRange(result);
            }
            catch(Exception e)
            {
                throw new Exception(e.Message);
            }

            return customers;
        }

        [HttpPost]
        [Route("api/Customer/CreateNewCustomers")]
        public void CreateNewCustomers([FromBody]IEnumerable<Customer> customers)
        {
            try
            {
                foreach (var customer in customers)
                {
                    this._customerRepo.CreateCustomers(customer);
                }
            }
            catch(Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}