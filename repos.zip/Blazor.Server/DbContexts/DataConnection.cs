﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace Blazor.Server.DbContexts
{
    public class DataConnection : IDataConnection
    {
        private readonly IDbConnection connection;

        protected DataConnection(string connectionString)
        {
            var connString = ConfigurationManager.ConnectionStrings[connectionString.Replace("name", string.Empty)].ConnectionString;

            this.connection = new SqlConnection(connString);
            this.connection.Open();
        }

        public IDbConnection Connection
        {
            get
            {
                if (this.connection.State != ConnectionState.Open && this.connection.State != ConnectionState.Connecting)
                {
                    this.connection.Open();
                }

                while (this.connection.State == ConnectionState.Connecting)
                {
                    Thread.Sleep(500);
                }

                return this.connection;
            }
        }

        public void Dispose()
        {
            this.Dispose(true);
        }

        private void Dispose(bool isDisposing)
        {
            if(isDisposing && this.connection != null && this.connection.State != ConnectionState.Closed)
            {
                this.connection.Close();
                this.connection.Dispose();
            }
        }
    }
}
