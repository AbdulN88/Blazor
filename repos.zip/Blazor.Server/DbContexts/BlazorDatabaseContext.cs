﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Blazor.Server.DbContexts
{
    public class BlazorDatabaseContext : DataConnection
    {
        public BlazorDatabaseContext() : base("name:BlazorEntities")
        {
        }

        public static BlazorDatabaseContext DbContext
        {
            get {
                return new BlazorDatabaseContext();
            }
        }
    }
}
