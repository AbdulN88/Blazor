﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Blazor.Server.DbContexts
{
    public interface IDataConnection : IDisposable
    {
        IDbConnection Connection { get; }
    }
}
